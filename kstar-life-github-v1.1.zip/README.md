# K-STAR LIFE v1.1 · GitHub 版

中文 K-pop 互动人生模拟网页游戏。包含五种身份、四个组合与28位成员、行程、相遇、关系互动、离线聊天、可选 AI 聊天、出道评估、职业企划及本地存档。

本项目无需安装前端依赖或编译，可部署到 GitHub Pages。角色对话、性格、关系与行程均为虚构，非官方项目，不与真人连接。

## 上传 GitHub 并发布网页

1. 解压项目包。在 GitHub 新建仓库，例如 `kstar-life`。使用 GitHub Free 发布 Pages 时，请创建 Public 公开仓库。
2. 在仓库首页选择 **Add file → Upload files**，上传解压后的项目内容，提交到 `main` 分支。`index.html` 必须直接在仓库根目录，不能仅上传 ZIP 或把整个项目额外嵌套一层。
3. 确认 `.github/workflows/deploy-pages.yml` 也已上传。如果手机文件选择器没有显示该目录，可在 GitHub 点 **Add file → Create new file**，文件名填写 `.github/workflows/deploy-pages.yml`，复制包内同名文件的完整内容，然后提交。
4. 进入仓库 **Settings → Pages**，将 **Build and deployment → Source** 设为 **GitHub Actions**。
5. 进入 **Actions → Deploy K-STAR LIFE to GitHub Pages → Run workflow**，选择 `main`，运行一次。若首次上传时因尚未启用 Pages 失败，完成第4步后重新运行即可。
6. 等待 `build` 和 `deploy` 都成功，打开 Settings → Pages 展示的网页地址。普通项目地址通常为 `https://你的用户名.github.io/kstar-life/`。
7. 之后提交到 `main` 或 `master` 时，工作流自动检查 JavaScript 并更新网页。

如果只想把源码存到 GitHub，可以做到第2步，暂时不启用 Pages。

如果你原本想「源码上传 GitHub、网页继续托管 Netlify」，请使用上一版 Netlify 项目包导入 Git 仓库；该包保留 Netlify 代理函数。此 GitHub Pages 版已改为纯静态网页。

## AI 设置

游戏不接 API 也能正常玩。

在游戏 **我的 → API 设置**：

1. 填写 OpenAI 兼容 API 的根地址，例如服务商给出的 `https://api.example.com/v1`。不要填 `/chat/completions`。
2. 输入自己的 API Key。
3. 点击「拉取模型」，或手动输入模型 ID（部分服务商不支持拉取）。
4. 点击「测试连接」，成功后勾选「使用 AI 生成聊天回复」并保存。

GitHub Pages 是静态托管，不能执行本版原来的 Netlify 代理函数。本版只提供浏览器直连，服务商必须允许来自你的网站的 CORS 请求。若出现网络 / CORS 错误，换用支持浏览器调用的兼容接口，或之后另行接入服务端代理。模型、地址和密钥正确，并不保证服务商允许浏览器直连。

密钥仅保存在当前标签页会话中，不在代码、GitHub 仓库、GitHub Actions 或存档中保存。不要把 API Key 写进代码或提交到仓库。AI 对话会把最近12条聊天、角色介绍及关系数值发送给所选服务商。

## 存档与换网址

进度自动保存到当前浏览器；可在「我的」导出或导入 JSON 存档。GitHub Pages 使用新域名后，旧 Netlify 存档不会自动出现。请先从原网站导出，再在新网站导入。换设备或清理浏览器数据前也应导出备份。

## 本地运行

```bash
python3 -m http.server 8080
```

浏览器打开 `http://localhost:8080`。

语法检查：

```bash
npm run check
```

## 游戏规则与首版范围

每天3次行动，每项行程每天一次，社交互动每天一次。活动随机遇见成员，熟悉≥15、信任≥10后解锁私聊。聊天关系成长每天最多3次。

练习生声乐≥40、舞蹈≥40、舞台≥25可参加出道评估；其他身份的职业企划需要资金₩1000和舞台≥25。职业企划间隔7天。

主要关系玩法驱动好感、熟悉、信任和警戒。吸引、嫉妒、依赖、舆论风险保留数据结构，暂未形成完整玩法。本版没有完整恋爱、实时新闻、多人联机或云存档。AI生成聊天文字，游戏数值仍由本地规则控制。

## 公开资料来源

核对日期 2026-09-30，名单为版本快照，不自动同步现实变化。年份仅为模拟开始年份，不加载真实活动历史或未来行程。

- Stray Kids：https://straykids.jype.com/profile
- TWICE：https://twice.jype.com/profile
- ITZY：https://itzy.jype.com/profile
- ENHYPEN：https://beliftlab.com/artist/profile/ENHYPEN

仅摘录公开成员艺名、组合、公司及生日作索引。没有真人照片或真实私生活数据。

## 部署文档

- GitHub 上传文件：https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
- GitHub Pages 自定义工作流：https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
