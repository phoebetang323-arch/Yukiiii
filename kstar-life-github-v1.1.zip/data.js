'use strict';
window.KDATA={checked:'2026-09-30',groups:[
{name:'Stray Kids',company:'JYP Entertainment',color:'#ceb3ff',source:'https://straykids.jype.com/profile',members:[['BANG CHAN','1997-10-03'],['LEE KNOW','1998-10-25'],['CHANGBIN','1999-08-11'],['HYUNJIN','2000-03-20'],['HAN','2000-09-14'],['FELIX','2000-09-15'],['SEUNGMIN','2000-09-22'],['I.N','2001-02-08']]},
{name:'TWICE',company:'JYP Entertainment',color:'#ffb6ce',source:'https://twice.jype.com/profile',members:[['NAYEON','1995-09-22'],['JEONGYEON','1996-11-01'],['MOMO','1996-11-09'],['SANA','1996-12-29'],['JIHYO','1997-02-01'],['MINA','1997-03-24'],['DAHYUN','1998-05-28'],['CHAEYOUNG','1999-04-23'],['TZUYU','1999-06-14']]},
{name:'ITZY',company:'JYP Entertainment',color:'#b4e9b9',source:'https://itzy.jype.com/profile',members:[['YEJI','2000-05-26'],['LIA','2000-07-21'],['RYUJIN','2001-04-17'],['CHAERYEONG','2001-06-05'],['YUNA','2003-12-09']]},
{name:'ENHYPEN',company:'BELIFT LAB',color:'#a7d8fa',source:'https://beliftlab.com/artist/profile/ENHYPEN',members:[['JUNGWON','2004-02-09'],['JAY','2002-04-20'],['JAKE','2002-11-15'],['SUNGHOON','2002-12-08'],['SUNOO','2003-06-24'],['NI-KI','2005-12-09']]}
],roles:{'练习生':{desc:'从练习室出发，争取属于你的出道机会。',fans:0,money:3000,vocal:20,dance:20,stage:10},'新人爱豆':{desc:'第一次站上舞台，努力让世界记住你的名字。',fans:1500,money:8000,vocal:45,dance:45,stage:40},'粉丝':{desc:'记录追星日常，在公开活动里遇见喜欢的人。',fans:50,money:10000,vocal:10,dance:10,stage:10},'制作人':{desc:'用一首歌打开合作的门，打造自己的音乐作品。',fans:300,money:12000,vocal:50,dance:15,stage:25},'经纪人':{desc:'统筹行程、维系合作，在幕后写下自己的故事。',fans:100,money:12000,vocal:15,dance:15,stage:30}},actions:[
{id:'vocal',title:'声乐练习',place:'录音室 · 个人训练',icon:'♫',desc:'磨练音准和表达，让下一次舞台更有底气。',energy:18,cost:100,skill:'vocal',gain:7},
{id:'dance',title:'舞蹈练习',place:'练习室 · 镜面前',icon:'✧',desc:'练习基本功与舞台动作，累积你的实力。',energy:20,cost:100,skill:'dance',gain:7},
{id:'show',title:'音乐节目',place:'电视台 · 公开录制',icon:'◉',desc:'参与录制或舞台工作，有机会在活动区认识新朋友。',energy:25,cost:150,skill:'stage',gain:5,meet:true,fans:180},
{id:'challenge',title:'Dance Challenge',place:'舞蹈工作室 · 合作企划',icon:'↗',desc:'拍摄一段合作短片，累积舞台经验与人气。',energy:22,cost:200,skill:'dance',gain:4,meet:true,fans:120},
{id:'cafe',title:'行业交流会',place:'咖啡馆 · 官方交流活动',icon:'☕',desc:'和业内伙伴交流创作，认识不同组合的成员。',energy:12,cost:120,meet:true,fans:15},
{id:'work',title:'完成工作',place:'工作室 · 今日委托',icon:'◇',desc:'完成与你身份相关的工作，赚取日常开支。',energy:20,cost:0,income:900,fans:30},
{id:'sns',title:'发布 SNS',place:'社交平台 · 分享日常',icon:'♡',desc:'分享练习片段或生活记录，和关注你的人保持联系。',energy:10,cost:0,fans:80},
{id:'rest',title:'好好休息',place:'宿舍 · 放松时刻',icon:'☾',desc:'暂时放下行程，恢复体力与心情。',energy:-35,cost:0}
]};
